import warnings

warnings.warn(
  "The compatability module is deprecated and will be removed in 1.0",
  FutureWarning,
  stacklevel=2
)
